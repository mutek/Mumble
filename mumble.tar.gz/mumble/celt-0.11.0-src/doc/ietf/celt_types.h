#ifndef _CELT_TYPES_H
#define _CELT_TYPES_H

typedef short celt_int16;
typedef unsigned short celt_uint16;
typedef int celt_int32;
typedef unsigned int celt_uint32;
typedef long long celt_int64;
typedef unsigned long long celt_uint64;

#endif /* _CELT_TYPES_H */
